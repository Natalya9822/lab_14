package ru.muctr.Laba13;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class Server {
    private static final int PORT = 8189;
    private static ServerSocket server;
    private static Socket socket;
    private static DataInputStream in;
    private static DataOutputStream out;
    private static List<String> topic1Tasks;

    public static void main(String[] args) {
        try {
            server = new ServerSocket(PORT); //в конструктор серверного сокета передаем порт, который он будет слушать
            System.out.println("Server started");
            socket = server.accept();  //ожидание подключения клиента
            System.out.println("Client connected");

            in = new DataInputStream(socket.getInputStream());
            out = new DataOutputStream(socket.getOutputStream());

            while (true) {             // бесконечно ожидаем сообщения от клиента
                String str = in.readUTF();  //в перемнную str записываем сообщение от клиента
                if (str.equals("/end")) {
                    System.out.println("Client disconnected");
                    break;
                }
                System.out.println("Client: " + str);
                out.writeUTF("ECHO: " + str);  //эхо-сервер возвращает клиенту его сообщение
            }
        }catch (IOException e){
            e.printStackTrace();
        }finally {
            try {
                socket.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            try {
                server.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public static void save() {             //сохранение списков задач в файлы
        File file1 = new File("Project1.txt");
        try (BufferedWriter writer1 = new BufferedWriter(new FileWriter(file1))){
            Iterator<String> itr = topic1Tasks.iterator();
            while (itr.hasNext()){
                writer1.write(itr.next());
                writer1.newLine();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static List<String> readTasks() {   //считывание заданий из файлов
        List<String> lines  = new ArrayList<>();
        try {
            File file = new File("Project1.txt");
            if (!file.exists()) {
                System.err.printf("File %s doesn't exist\n", file.getPath());
            } else {
                try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
                    String line = new String();
                    line = reader.readLine();
                    while (line != null) {
                        lines.add(line);
                        line = reader.readLine();
                    }

                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return lines;
    }
}
