package sample;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;

import java.io.*;
import java.net.Socket;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;

public class Controller implements Initializable {
    private final String SERVER_ADDR = "localhost";
    private static final int PORT = 8189;
    private static Socket socket;
    private static DataInputStream in;
    private static DataOutputStream out;
    @FXML
    public VBox vbox;
    @FXML
    public TextField deleteTextField;

    public List<String> tasks;

    @FXML
    public Button btnAdd;
    @FXML
    public Button btnDel;
    @FXML
    public Button btnTopic1;
    @FXML
    public TextArea textArea;
    @FXML
    public TextField textField1;


    @FXML
    public void clickBtnAdd(ActionEvent actionEvent) {   //обработка нажатия кнопки "Добавить задачу"
        textField1.setVisible(true);
        textField1.requestFocus();
    }

    @FXML
    public void clickBtnDel(ActionEvent actionEvent) {  //обработка нажатия кнопки "Удалить"
        deleteTextField.setVisible(true);
        deleteTextField.requestFocus();
    }

    @FXML
    public void textFieldClick(ActionEvent actionEvent) {  //обработка нажатия Enter на textField (id "textField") при добавлении новой задачи
        int index = 0;
            index = Integer.parseInt(tasks.get(tasks.size() - 1).substring(0,1));
            System.out.println(index);
            tasks.add((index + 1) + ". " + textField1.getText());
            textArea.appendText((index + 1) + ". " + textField1.getText()+"\n\n");


        textField1.clear();
        textField1.setVisible(false);
    }

    @FXML
    public void deleteTask(ActionEvent actionEvent) {       //обработка нажатия Enter на textField (id "deleteTextField") при удалении задачи из списка

    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        try{
            socket = new Socket(SERVER_ADDR, PORT);
            in = new DataInputStream(socket.getInputStream());
            out = new DataOutputStream(socket.getOutputStream());

            new Thread(()-> {
                    try {
                        while(true) {
                            String str = in.readUTF();
                            textArea.appendText(str);
                        }
                    } catch (IOException e) {
                        e.printStackTrace();
                    }finally {
                        try{
                            socket.close();
                        }catch (IOException e){
                            e.printStackTrace();
                        }
                    }
            }).start();
        }catch (IOException e){
            e.printStackTrace();
        }
    }

}
