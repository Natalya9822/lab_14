package ru.muctr.Laba13;

public class StartServer {
    public static void main(String[] args) {
        new Server();
    }
}
